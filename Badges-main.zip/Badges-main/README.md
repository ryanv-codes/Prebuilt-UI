# Badges
All badges created using pure simple html and css
